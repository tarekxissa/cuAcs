#ifndef ANIMALHEADERS_H
#define ANIMALHEADERS_H

#include "mammal.h"
#include "bird.h"
#include "animal.h"
#include "reptile.h"
#include "fish.h"
#include "amphibian.h"
#endif // ANIMALHEADERS_H
