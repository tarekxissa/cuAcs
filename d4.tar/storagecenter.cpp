#include <iostream>
#include "storagecenter.h"
using namespace std;


StorageCenter::StorageCenter(){


}

StorageCenter::~StorageCenter(){}

string StorageCenter::getName(){

    return this->name;
}
